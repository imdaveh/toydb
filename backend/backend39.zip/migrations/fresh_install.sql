-- Single full setup script for a brand-new ToyDB database.
-- Run this in phpMyAdmin against a blank database or as a fresh database import.
-- This script creates the entire schema for the current app.

CREATE DATABASE IF NOT EXISTS toydb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toydb;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS collection_shares (
  owner_user_id INT UNSIGNED NOT NULL,
  viewer_user_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (owner_user_id, viewer_user_id),
  FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (viewer_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS toys (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  copy INT UNSIGNED NOT NULL DEFAULT 1,
  is_wishlist BOOLEAN NOT NULL DEFAULT FALSE,
  for_sale BOOLEAN NOT NULL DEFAULT FALSE,
  hidden BOOLEAN NOT NULL DEFAULT FALSE,
  name VARCHAR(255) NOT NULL,
  manufacturer VARCHAR(255),
  series VARCHAR(255),
  sub_series VARCHAR(255),
  theme VARCHAR(255),
  type VARCHAR(255),
  `release_wave` VARCHAR(255),
  `faction` VARCHAR(255),
  `manufacturer_id` VARCHAR(255),
  toyline VARCHAR(255),
  `year` SMALLINT UNSIGNED,
  cost DECIMAL(10,2),
  `value` DECIMAL(10,2),
  source VARCHAR(255),
  notes TEXT,
  `condition` VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS toy_photos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  toy_id INT UNSIGNED NOT NULL,
  filename VARCHAR(512) NOT NULL,
  original_name VARCHAR(512),
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (toy_id) REFERENCES toys(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

UPDATE toy_photos SET sort_order = id WHERE sort_order = 0;

CREATE TABLE IF NOT EXISTS tags (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO tags (name) VALUES
  ('Box'),
  ('Carded'),
  ('Complete'),
  ('Damaged'),
  ('Incomplete'),
  ('Loose'),
  ('New'),
  ('Open'),
  ('Sealed')
ON DUPLICATE KEY UPDATE name = VALUES(name);

CREATE TABLE IF NOT EXISTS toy_tags (
  toy_id INT UNSIGNED NOT NULL,
  tag_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (toy_id, tag_id),
  FOREIGN KEY (toy_id) REFERENCES toys(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;